# rabin-crypto

## Program for encrypt and decrypt files used Rabin cryptosystem

**To run program with GUI: *gui_rabin.py***

**Usefull functuions that realized in *src/rabin_cryptosystem.py*:**
* file_encrypt
* file_decrypt
* extended_euclid(Advanced Euclidean Algorithm)
* fast_pow(fast exponentiation algorithm)
* is_prime(check the numbers for primary)
